# Hazra Bari Dual Temple — Advanced 2-in-1

Main Streamlit file: **uv.py**

## Added in this upgrade
- Dedicated Advanced Command Center
- Temple-aware smart devotional guidance for Maa Durga / Mahadev
- Personal devotion progress and score
- Daily Japa / Seva / Aarti / Sankalp goals
- Per-temple reminder scheduler stored in the database
- Live cloud activity view when Supabase is configured
- Configuration/health diagnostics
- Existing Darshan, Seva, Bhog, Japa, Sankalp, Aarti, Khetri, Navratri, donations, wallet, account, history, rooms, admin and Panchang modules retained
- Supabase schema extended for advanced goals/reminders/preferences
- Local Durgapur Panchang calculation using Swiss Ephemeris (Tithi, Nakshatra, sunrise, sunset, moonrise, moonset and Paksha)
- `PANCHANG_API_URL` is optional; the Panchang remains available without it

## Optional Streamlit Secrets
SUPABASE_URL = "https://YOUR_PROJECT.supabase.co"
SUPABASE_SERVICE_ROLE_KEY = "YOUR_SERVICE_ROLE_KEY"
PANCHANG_API_URL = "YOUR_PANCHANG_ENDPOINT"
ADMIN_EMAILS = "your-admin-email@example.com"

Panchang works without an API by calculating astronomical values locally for Durgapur. An optional API can enrich/override local values.
